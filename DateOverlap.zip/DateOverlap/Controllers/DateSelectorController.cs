﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DateOverlap.Controllers
{
    public class DateSelectorController : Controller
    {
        // GET: DateSelector
        public ActionResult Index()
        {
            return View();
        }
    }
}