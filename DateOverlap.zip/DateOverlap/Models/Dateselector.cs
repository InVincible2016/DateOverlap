﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DateOverlap.Models
{
    public class Dateselector
    {

        public DateTime dtmDate { get; set; }

    }
}